AuctionHouse
============


- sistem de licitatie inversa: furnizorii vor scadea preturile 
