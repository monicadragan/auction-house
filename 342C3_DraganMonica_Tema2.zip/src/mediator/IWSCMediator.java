package mediator;

/**
 * Interfata pentru WebService
 */
public interface IWSCMediator {

}
