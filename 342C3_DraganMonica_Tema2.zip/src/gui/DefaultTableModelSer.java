package gui;

import java.io.Serializable;

import javax.swing.table.DefaultTableModel;

public class DefaultTableModelSer extends DefaultTableModel implements Serializable{

	private static final long serialVersionUID = 1L;

	public DefaultTableModelSer() {
		super();
	}
	
}
