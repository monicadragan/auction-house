package types;

/**
 * Tipul unui utilizator
 */
public enum UserType {

	BUYER, SELLER
};
